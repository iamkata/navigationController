//
//  ViewController.m
//  EOCNavClass
//
//  Created by sy on 2017/10/13.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "ViewController.h"
#import "TwoViewCtr.h"

/*
 nav.navigationBar;
 nav.viewControllers;
 nav.toolbar// 默认隐藏
 
 导航区
 内容区
 工具区
 
 ios 7.0前 导航条拟物化风格，导航条是不透明（内容区在导航条下：64开始）
 ios 7.0后 扁平化风格，导航条模式是透明的（0/64）
 1 透明 内容全局（0）
 2 透明 内容从64开始（0，iphonex 84）
 3 不透明 内容全局（0）
 4 不透明 内容从64开始（0）
 
 导航条 scrollview
 */
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"导航条";
    UINavigationController *nav;
   // self.view.backgroundColor = [UIColor blueColor];
     self.navigationController.toolbarHidden = NO;
    
    self.navigationController.view;
}

- (IBAction)pressBt:(id)sender{
    
    TwoViewCtr *twoVCtr = [[TwoViewCtr alloc] initWithNibName:@"TwoViewCtr" bundle:nil];
    [self.navigationController pushViewController:twoVCtr animated:YES];
    
//    [self.navigationController addChildViewController:[TwoViewCtr new]];
    
}

@end
