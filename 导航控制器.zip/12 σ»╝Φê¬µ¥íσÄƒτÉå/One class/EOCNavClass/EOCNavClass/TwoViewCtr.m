//
//  TwoViewCtr.m
//  NavClass
//
//  Created by sy on 2017/10/12.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "TwoViewCtr.h"
#import "ThreeVCtr.h"

@interface TwoViewCtr (){
    
    IBOutlet UIScrollView *_scrollView;
    
}

@end

@implementation TwoViewCtr
/*
 
 对scrollview的影响
 
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"second";
    
    //[self translucentAnd64];
    
    //self.navigationController.navigationBar.translucent = NO;
    
    //self.automaticallyAdjustsScrollViewInsets = NO; // ios 11
    
    //_scrollView.contentInsetAdjustmentBehavior = NO;
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 200)];
    label.text = @"在view上";
    label.backgroundColor = [UIColor redColor];
    [self.view addSubview:label];
    
    UILabel *labelscr = [[UILabel alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-200, 0, 200, 200)];
    labelscr.text = @"在scrollview上";
    labelscr.backgroundColor = [UIColor yellowColor];
    [_scrollView addSubview:labelscr];
}

- (void)viewWillLayoutSubviews{

    [super viewWillLayoutSubviews];
    [_scrollView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 100)];
    [_scrollView setContentSize:CGSizeMake(self.view.frame.size.width, self.view.frame.size.height*1.5)];
}

//一些属性对管理控制器view起始位置的影响

// 透明全局（默认）
- (void)translucentAndAll{
    
    self.navigationController.navigationBar.translucent = YES;
    self.edgesForExtendedLayout = UIRectEdgeAll;
//    self.automaticallyAdjustsScrollViewInsets = YES;
//    self.extendedLayoutIncludesOpaqueBars = NO;
}

//透明 从64开始
- (void)translucentAnd64{
    
    self.navigationController.navigationBar.translucent = YES;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    //    self.automaticallyAdjustsScrollViewInsets = YES;
    //    self.extendedLayoutIncludesOpaqueBars = NO;
}

//不透明 从64开始
- (void)noTranslucentAnd64{
    
    self.navigationController.navigationBar.translucent = NO;
   // self.edgesForExtendedLayout = UIRectEdgeNone;
}

//不透明 全局
- (void)noTranslucentAndAll{
    
    self.navigationController.navigationBar.translucent = NO;
    self.extendedLayoutIncludesOpaqueBars = YES;
   // self.edgesForExtendedLayout = UIRectEdgeNone;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    
}

- (IBAction)pressBt:(id)sender{
    
    ThreeVCtr *threVCtr = [ThreeVCtr new];
    [self.navigationController pushViewController:threVCtr animated:YES];
    
}

@end
