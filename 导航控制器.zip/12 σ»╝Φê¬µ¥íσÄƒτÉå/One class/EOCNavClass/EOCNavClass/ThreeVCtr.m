//
//  ThreeVCtr.m
//  NavClass
//
//  Created by sy on 2017/10/12.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "ThreeVCtr.h"
#import "TwoViewCtr.h"
#import "FourViewCtr.h"
#import "FiveViewCtr.h"

/*
 导航区navigationBar 管理 items（UINavigationItem 看作是model）
 
 */
@interface ThreeVCtr (){
    
    UIView *_tview;
}

@end

@implementation ThreeVCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"ThreeVCtr";
    
    self.navigationController.navigationBar;
    self.navigationItem;
    self.navigationController.navigationBar;
    
    _tview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 100, 50)];
    _tview.backgroundColor = [UIColor redColor];
   
    
   // [self addViewToNavbar];
}


- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar addSubview:_tview];
    
}

- (void)viewWillDisappear:(BOOL)animated{
    
    [super viewWillDisappear:animated];
    [_tview removeFromSuperview];
}


- (void)addViewToNavbar{
    
    
    
}

- (IBAction)pressBt:(id)sender{
    
    FourViewCtr *fourVCtr = [FourViewCtr new];
    [self.navigationController pushViewController:fourVCtr animated:YES];
    
}

@end
