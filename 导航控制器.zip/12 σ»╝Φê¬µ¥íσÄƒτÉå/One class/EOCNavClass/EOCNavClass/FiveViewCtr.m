//
//  FiveViewCtr.m
//  NavClass
//
//  Created by sy on 2017/10/12.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "FiveViewCtr.h"
#import "TwoViewCtr.h"
#import "FourViewCtr.h"

@interface FiveViewCtr ()

@end

@implementation FiveViewCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"FiveViewCtr";
}

- (IBAction)pressBt:(id)sender{
    
    NSMutableArray *array = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    [array removeLastObject];
    [array removeLastObject];
    
    self.navigationController.viewControllers = array;
    
    [self.navigationController popViewControllerAnimated:YES];
    
   // [self.navigationController popToViewController:[array lastObject] animated:YES];
}


@end
