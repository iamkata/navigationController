//
//  FourViewCtr.m
//  NavClass
//
//  Created by sy on 2017/10/12.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "FourViewCtr.h"
#import "TwoViewCtr.h"
#import "FiveViewCtr.h"
@interface FourViewCtr ()

@end

@implementation FourViewCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"FourViewCtr";
}

- (IBAction)pressBt:(id)sender{
    
    FiveViewCtr *fiveVCtr = [FiveViewCtr new];
    [self.navigationController pushViewController:fiveVCtr animated:YES];
}


@end
