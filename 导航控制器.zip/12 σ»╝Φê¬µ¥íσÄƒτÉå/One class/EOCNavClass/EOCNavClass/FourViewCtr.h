//
//  FourViewCtr.h
//  NavClass
//
//  Created by sy on 2017/10/12.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FourViewCtr : UIViewController

@end
