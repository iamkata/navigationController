//
//  EocNavBlackLineVCtr.h
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EocNavBlackLineVCtr : UIViewController

@end
