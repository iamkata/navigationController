//
//  EOCEOCAnimaTheoryVC.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCEOCAnimaTheoryVC.h"

@interface EOCEOCAnimaTheoryVC (){
    
    
    UIView *transferView;
    UIView *preView;
    UINavigationBar *preNavBar;
    
    
}

@end

@implementation EOCEOCAnimaTheoryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"动画原理";
    //UIView *jjj = self.navigationController.view;
    UIView *containView = self.parentViewController.view;
    
}

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
   
}





@end
