 //
//  EocNavBlackLineVCtr.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EocNavBlackLineVCtr.h"

@interface EocNavBlackLineVCtr (){
    IBOutlet UIScrollView *_scorllView;
}

@end

@implementation EocNavBlackLineVCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"黑线处理";
    self.navigationController.navigationBar.barTintColor = [UIColor yellowColor];
   [_scorllView setContentSize:CGSizeMake(_scorllView.frame.size.width, _scorllView.frame.size.height + 300)];
    
    UIImageView *iamgeV = [self findBackLineImageV:self.navigationController.navigationBar];
    iamgeV.hidden = YES;
    
}



- (UIImageView *)findBackLineImageV:(UIView*)view{
    
    
    if([view isKindOfClass:[UIImageView class]] && view.frame.size.height <= 1){
        
        return (UIImageView*)view;
    }
    NSArray *viewAry = view.subviews;
    for (int i = 0; i < viewAry.count; i++) {
        
        UIView *tmpV = [self findBackLineImageV:viewAry[i]];
        if (tmpV) {
            return (UIImageView*)tmpV;
        }
    }
    return nil;
}

- (void)blackNavLine{
    
    self.navigationController.navigationBar.clipsToBounds = YES;
    
}







@end
