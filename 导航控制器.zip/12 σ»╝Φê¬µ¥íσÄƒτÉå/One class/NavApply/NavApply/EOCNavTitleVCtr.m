//
//  EOCNavTitleVCtr.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavTitleVCtr.h"

@interface EOCNavTitleVCtr ()

@end

@implementation EOCNavTitleVCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"标题方式";
   
}





@end
