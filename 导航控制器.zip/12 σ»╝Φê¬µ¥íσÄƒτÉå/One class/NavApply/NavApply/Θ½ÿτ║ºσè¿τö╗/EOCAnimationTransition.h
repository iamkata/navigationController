//
//  EOCAnimationTransition.h
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface EOCAnimationTransition : NSObject<UIViewControllerAnimatedTransitioning>

@end
