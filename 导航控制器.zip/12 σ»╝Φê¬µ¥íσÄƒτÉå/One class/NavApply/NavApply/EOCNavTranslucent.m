//
//  EOCNavTranslucent.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavTranslucent.h"


@interface EOCNavTranslucent (){
    IBOutlet UIScrollView *_scorllView;
}

@end

@implementation EOCNavTranslucent

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.title = @"导航条透明度";
    //self.navigationController.navigationBar.translucent = NO;
    [_scorllView setContentSize:CGSizeMake(_scorllView.frame.size.width, _scorllView.frame.size.height + 300)];
    
    //[self transluentStyle];
}

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
    //一定要在viewDidAppear里面设置
    [self transluentTwoStyle];
}

//全透明  放一个全透明图片
- (void)transluentStyle{
    [self.navigationController.navigationBar setBackgroundImage:self.image forBarMetrics:UIBarMetricsDefault];
}

//全透明  遍历
- (void)transluentTwoStyle{
    
    NSArray *ary  = [self.navigationController.navigationBar subviews];
    UIColor *alphaColor = [[UIColor whiteColor] colorWithAlphaComponent:0];
    for (int i = 0; i < ary.count; i++) {
        UIView *view = ary[i];
        view.backgroundColor = alphaColor;
        
        for (int j = 0; j < view.subviews.count; j++) {
            UIView *subView = view.subviews[j];
            subView.backgroundColor = alphaColor;
            for (int k = 0; k < subView.subviews.count; k++) {
                UIView *subsubView = subView.subviews[k];
                subsubView.backgroundColor = alphaColor;
            }
        }
        if([view isKindOfClass:NSClassFromString(@"_UIBarBackground")]){
            
            view.backgroundColor = alphaColor;

        }
    }
}

//画个图片
- (UIImage*)image{
    UIGraphicsBeginImageContext(CGSizeMake(100, 100));
    [[[UIColor whiteColor] colorWithAlphaComponent:0] setFill];
    UIRectFill(CGRectMake(0, 0, 100, 100));
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}





@end
