//
//  EOCNavOtherVCtr.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavOtherVCtr.h"

@interface EOCNavOtherVCtr ()

@end

@implementation EOCNavOtherVCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"其他";
   
   
}

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
    
    
}

- (void)viewDidDisappear:(BOOL)animated{
    
    [super viewDidDisappear:animated];
   
}




@end
