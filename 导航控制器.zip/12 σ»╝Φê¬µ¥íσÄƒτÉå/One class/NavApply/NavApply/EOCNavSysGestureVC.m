//
//  EOCNavSysGestureVC.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavSysGestureVC.h"
#import <objc/runtime.h>

@interface EOCNavSysGestureVC ()

@end

@implementation EOCNavSysGestureVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"替换系统手势";
    
    
}




- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
    
}


@end
