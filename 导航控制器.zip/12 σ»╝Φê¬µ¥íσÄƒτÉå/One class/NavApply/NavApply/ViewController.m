//
//  ViewController.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "ViewController.h"
#import "EOCNavTranslucent.h"
#import "EocNavBlackLineVCtr.h"
#import "EOCNavItemGapVCtr.h"
#import "EOCNavTitleVCtr.h"
#import "EOCNavOtherVCtr.h"
#import "EOCEOCAnimaTheoryVC.h"
#import "EOCNavSysGestureVC.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"主页";
    
//    UIImage *image = [UIImage imageNamed:@"arrow.png"];
//    image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
//    
//    UIBarButtonItem *backButtonTwo = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStylePlain target:nil action:nil];
//    
//    self.navigationItem.leftBarButtonItem = backButtonTwo;
    
}

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
}

#pragma mark - tableView delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 8;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    if (indexPath.row == 0) {
        cell.textLabel.text = @"导航栏透明度";
        cell.backgroundColor = [UIColor redColor];
    }else if (indexPath.row == 1) {
        cell.textLabel.text = @"导航条地下黑线";
        cell.backgroundColor = [UIColor yellowColor];
    }else if (indexPath.row == 2) {
        cell.textLabel.text = @"导航条Item间隔";
        cell.backgroundColor = [UIColor greenColor];
    }else if (indexPath.row == 3) {
        cell.textLabel.text = @"导航条标题";
        cell.backgroundColor = [UIColor orangeColor];
    }else if (indexPath.row == 4) {
        cell.textLabel.text = @"其他";
        cell.backgroundColor = [UIColor redColor];
    }else if (indexPath.row == 5) {
        cell.textLabel.text = @"转场动画原理解析";
        cell.backgroundColor = [UIColor yellowColor];
    }
    else if (indexPath.row == 6) {
        cell.textLabel.text = @"系统转场动画手势替换";
        cell.backgroundColor = [UIColor greenColor];
    }
    else if (indexPath.row == 7) {
        cell.textLabel.text = @"转场高级动画";
        cell.backgroundColor = [UIColor orangeColor];
    }
    else{
        cell.textLabel.text = @"3";
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UIViewController *eocNav = nil;
    if (indexPath.row == 0) {
        eocNav = [EOCNavTranslucent new];
    }else if (indexPath.row == 1){
        eocNav = [EocNavBlackLineVCtr new];
    }else if(indexPath.row == 2){
        eocNav = [EOCNavItemGapVCtr new];
    }else if(indexPath.row == 3){
        eocNav = [EOCNavTitleVCtr new];
    }else if(indexPath.row == 4){
        eocNav = [EOCNavOtherVCtr new];
    }
    else if(indexPath.row == 5){
        eocNav = [EOCEOCAnimaTheoryVC new];
    }else if(indexPath.row == 6){
        eocNav = [EOCNavSysGestureVC new];
    }
    
    [self.navigationController pushViewController:eocNav animated:YES];
    
}


@end
