//
//  EOCNavItemGapVCtr.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavItemGapVCtr.h"

@interface EOCNavItemGapVCtr (){

}

@end

@implementation EOCNavItemGapVCtr

/*
  A 转场到 B （A push B）
  A的viewDidDisappear先执行 还是B的viewDidAppear先执行
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Item间距";
    
    
    
    //3. 导航条的隐藏
    self.navigationController.navigationBarHidden = YES;
    //self.navigationController.navigationBar.hidden = YES;
    
    
    // return;
    
   // [self backArrowImage];
    
    
    //1. 添加间距
    NSMutableArray *barItems = [NSMutableArray array];
    
    UIBarButtonItem *barItem = [[UIBarButtonItem alloc] initWithTitle:@"Nav" style:UIBarButtonItemStylePlain target:self action:@selector(showNav)];
    
    UIBarButtonItem *barItemSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    barItemSpace.width = 60;
    
    UIBarButtonItem *barItemT = [[UIBarButtonItem alloc] initWithTitle:@"view" style:UIBarButtonItemStylePlain target:self action:@selector(showNavTwo)];
    
    [barItems addObject:barItem];
    [barItems addObject:barItemSpace];
    [barItems addObject:barItemT];
    
    self.navigationItem.rightBarButtonItems = barItems;
}


- (IBAction)showNav{
    
    self.navigationController.navigationBarHidden = NO;
    
}
- (IBAction)showNavTwo{
    
    self.navigationController.navigationBar.hidden = NO;
    
}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//
//    [self.navigationController popViewControllerAnimated:YES];
//}

//2. 修改系统返回按钮的图片
- (void)backArrowImage{
    UIImage *image = [UIImage imageNamed:@"arrow.png"];
    image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];

    self.navigationController.navigationBar.backIndicatorImage = image;
    self.navigationController.navigationBar.backIndicatorTransitionMaskImage = image;
}


- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
    
}



@end
