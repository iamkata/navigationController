//
//  EOCNavAdvanceAnimaVC.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavAdvanceAnimaVC.h"

@interface EOCNavAdvanceAnimaVC ()

@end

@implementation EOCNavAdvanceAnimaVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"高级动画";
    
}




@end
