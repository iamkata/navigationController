//
//  EOCNavViewCtr.m
//  NavApply
//
//  Created by sy on 2017/10/16.
//  Copyright © 2017年 EOC. All rights reserved.
//

/*
 作业：
 1 runtime 观察私有方法（了解私有的类）（手势+tranferView）
 2 push
 3 导航条动画
 */

#import "EOCNavViewCtr.h"
#import "EOCNavAnimation.h"
@interface EOCNavViewCtr ()<UINavigationControllerDelegate>{
    
    //系统提供了遵守UIViewControllerInteractiveTransitioning协议的类
    UIPercentDrivenInteractiveTransition *percentAnimation;
    UIViewController *VC;
}

@end

@implementation EOCNavViewCtr

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.delegate = self;
    
    //添加滑动手势
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGesture:)];
    [self.view addGestureRecognizer:panGesture];
}

- (void)panGesture:(UIPanGestureRecognizer*)gesture{
    
    // 获取 当前view（fromview）  pop的view（toView）
    
    CGPoint movePoint = [gesture translationInView:self.view];
    float precent = movePoint.x/[UIScreen mainScreen].bounds.size.width;
    
    //开始
    if (gesture.state == UIGestureRecognizerStateBegan) {
        percentAnimation = [[UIPercentDrivenInteractiveTransition alloc] init];
        [self popViewControllerAnimated:YES];
    //改变
    }else if (gesture.state == UIGestureRecognizerStateChanged){
       
        [percentAnimation updateInteractiveTransition:precent];
    }else {
    //完成
        if (percentAnimation.percentComplete > 0.5) { //pop
            [percentAnimation finishInteractiveTransition];
            
        }else { //取消pop
            [percentAnimation cancelInteractiveTransition];
            [self pushViewController:VC animated:NO];
        }
        percentAnimation = nil;
    }
}

#pragma mark - 导航控制器代理方法

// 返回动画进度对象
- (nullable id <UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController
                                   interactionControllerForAnimationController:(id <UIViewControllerAnimatedTransitioning>) animationController {

    if ([animationController isKindOfClass:[EOCNavAnimation class]]) {

        return percentAnimation;
    }
    return nil;
}

// 返回动画对象
- (nullable id <UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
                                            animationControllerForOperation:(UINavigationControllerOperation)operation
                                                         fromViewController:(UIViewController *)fromVC
                                                           toViewController:(UIViewController *)toVC {
    
    VC = fromVC;
    NSLog(@"fromVC -- %@",fromVC);
    //如果是pop返回, 就用我们自己的动画对象
    if (operation == UINavigationControllerOperationPop) {
        return [[EOCNavAnimation alloc] init];
    }
    return nil;
}

@end
