//
//  EOCNavAnimation.m
//  NavApply
//
//  Created by sy on 2017/10/16.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavAnimation.h"

@implementation EOCNavAnimation{
    
    id <UIViewControllerContextTransitioning> _transitionContext;
}


// 时间
- (NSTimeInterval)transitionDuration:(nullable id <UIViewControllerContextTransitioning>)transitionContext{
    
    return 0.5;
    
}

// 过程
- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext{
    // 获取 toView（ToViewCtr）／fromView（fromViewCtr）

    _transitionContext = transitionContext;
    
    //将要返回的VC
    UIViewController *toViewCtr = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    //从哪个界面返回的VC
    UIViewController *fromViewCtr = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIView *transferView =  transitionContext.containerView;
    
    //界面的动画添加到containerView里面,真正执行动画的还是UINavigationTransitionView
    
    // 规定的 如果用transferView.superview导航条会被遮住
    // transferView = [transferView superview]; // UINavigationTransitionView
    
    UIView *fromView = fromViewCtr.view;
    [transferView insertSubview:toViewCtr.view belowSubview:fromViewCtr.view];
    
    [self animationOneFromView:fromView transitionContext:transitionContext];
    //[self animationTwoTransferView:transferView];
}

- (void)animationOneFromView:(UIView*)fromView transitionContext:(id <UIViewControllerContextTransitioning>)transitionContext{
    [UIView animateWithDuration:[self transitionDuration:transitionContext] animations:^{
        fromView.frame =  CGRectMake(fromView.frame.size.width, fromView.frame.origin.y, fromView.frame.size.width, fromView.frame.size.height);
    } completion:^(BOOL finished) {
        // 务必 compelte Context
        [transitionContext completeTransition:YES];
    }];
}

- (void)animationTwoTransferView:(UIView*)transferView{
    
    CATransition *caTrans = [CATransition animation];
    caTrans.type = @"cube";
    caTrans.subtype = @"fromLeft";
    caTrans.duration = [self transitionDuration:_transitionContext];
    caTrans.fillMode = kCAFillModeForwards;
    caTrans.delegate = self;
    caTrans.removedOnCompletion = NO;
    
    [transferView.layer addAnimation:caTrans forKey:nil];
    [transferView exchangeSubviewAtIndex:0 withSubviewAtIndex:1];
}

// context结束
- (void)animationEnded:(BOOL) transitionCompleted{
    
    
}

//CATransition 代理方法
// 动画结束
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    
    [_transitionContext completeTransition:YES];
}

@end
