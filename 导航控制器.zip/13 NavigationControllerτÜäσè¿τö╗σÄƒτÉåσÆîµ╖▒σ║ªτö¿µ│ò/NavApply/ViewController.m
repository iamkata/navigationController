//
//  ViewController.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "ViewController.h"
#import "EOCEOCAnimaTheoryVC.h"
#import "EOCNavSysGestureVC.h"
#import "EOCNavAdvanceAnimaVC.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@end

@implementation ViewController


/*
 A控制器 跳转到 B控制
 A的viewDidDisappear 先执行，还是B的 viewDidAppear 先执行
 
 A先执行1
 B先执行2
 
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"主页";
    
}

- (void)viewDidDisappear:(BOOL)animated{
    
    
    [super viewDidDisappear:animated];
    NSLog(@"viewDidDisappear");
}

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
}

#pragma mark - tableView delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    if (indexPath.row == 0) {
        cell.textLabel.text = @"转场动画原理解析";
        cell.backgroundColor = [UIColor yellowColor];
    }
    else if (indexPath.row == 1) {
        cell.textLabel.text = @"系统转场动画手势替换";
        cell.backgroundColor = [UIColor greenColor];
    }
    else if (indexPath.row == 2) {
        cell.textLabel.text = @"转场高级动画";
        cell.backgroundColor = [UIColor orangeColor];
    }
    else{
        cell.textLabel.text = @"3";
    }
    return cell;
}

/*
 swift presentViewController  window 两个控制器的view
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UIViewController *eocNav = nil;
    if(indexPath.row == 0){
        eocNav = [EOCEOCAnimaTheoryVC new];
    }else if(indexPath.row == 1){
        eocNav = [EOCNavSysGestureVC new];
    }else{
        eocNav = [EOCNavAdvanceAnimaVC new];
    }
    
    
   // [self presentViewController:eocNav animated:YES completion:nil];
    
    [self.navigationController pushViewController:eocNav animated:YES];
    
}


@end
