//
//  ThirdViewCtr.m
//  NavApply
//
//  Created by sy on 2017/10/16.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "ThirdViewCtr.h"

@interface ThirdViewCtr ()

@end

@implementation ThirdViewCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
}

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    NSLog(@"3 viewDidAppear");
}

- (void)viewDidDisappear:(BOOL)animated{
    
    
    [super viewDidDisappear:animated];
    NSLog(@"3 viewDidDisappear");
}


@end
