//
//  EOCNavSysGestureVC.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavSysGestureVC.h"
#import <objc/runtime.h>
#import "ThirdViewCtr.h"

@interface EOCNavSysGestureVC ()

@end

@implementation EOCNavSysGestureVC

// 不涉及到用户隐私
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"替换系统侧滑手势为全局滑动返回";
    
    //interactivePopGestureRecognizer是UIGestureRecognizer类型的, 是UIPanGestureRecognizer的子类
    NSArray *targets = [self.navigationController.interactivePopGestureRecognizer valueForKey:@"targets"];
    id target = [[targets lastObject] valueForKey:@"target"];
    SEL actionSel = NSSelectorFromString(@"handleNavigationTransition:");
    //将系统的手势的action和target放到下面panGesture上
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:target action:actionSel];
    [self.view addGestureRecognizer:panGesture];
    
    [self scanMethods:NSClassFromString(@"UIScreenEdgePanGestureRecognizer")];
}

//使用runtime获取类的方法列表
- (void)scanMethods:(Class)class{
    
    unsigned int outCount = 0;
    Method *methods = class_copyMethodList(class, &outCount);
    for (int i = 0; i < outCount; i++) {
        
        SEL sel = method_getName(methods[i]);
        NSLog(@"%@", NSStringFromSelector(sel));
    }
}

@end
