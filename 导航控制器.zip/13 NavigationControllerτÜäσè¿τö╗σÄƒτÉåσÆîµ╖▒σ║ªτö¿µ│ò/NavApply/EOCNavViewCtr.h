//
//  EOCNavViewCtr.h
//  NavApply
//
//  Created by sy on 2017/10/16.
//  Copyright © 2017年 EOC. All rights reserved.
//  将Main.storyboard里面的导航控制器换成自己自定义的导航控制器

#import <UIKit/UIKit.h>

@interface EOCNavViewCtr : UINavigationController

@end
