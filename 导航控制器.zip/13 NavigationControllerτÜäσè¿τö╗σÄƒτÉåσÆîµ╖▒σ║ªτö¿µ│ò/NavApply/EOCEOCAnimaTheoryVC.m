//
//  EOCEOCAnimaTheoryVC.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCEOCAnimaTheoryVC.h"

@interface EOCEOCAnimaTheoryVC (){
    UIView *transferView;
    UIView *preView;
    UINavigationBar *preNavBar;
}

@end

@implementation EOCEOCAnimaTheoryVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"动画原理";
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGesture:)];
    
    [self.view addGestureRecognizer:panGesture];
}

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
   
}

/*
 1 当前的控制器view坐标的移动
 2 下一个控制器view的坐标移动
 */
- (void)panGesture:(UIPanGestureRecognizer*)gesture{
    
    // 获取 当前view（fromview）  pop的view（toView）
    
    //父View是UIViewControllerWrapperView
    UIView *containView = [self.view superview];
    UIView *fromView = self.view;
    UIView *toView = nil;
    NSArray *viewCtrAry = self.navigationController.viewControllers;
    if (viewCtrAry.count >= 2) {
        UIViewController *toViewCtr = viewCtrAry[viewCtrAry.count-2];
        toView = toViewCtr.view;
    }
    //把toView添加到它的父View上, 自己的下面
    [containView insertSubview:toView belowSubview:fromView];
    
    
    CGPoint movePoint = [gesture translationInView:self.view];
    [gesture setTranslation:CGPointZero inView:self.view];
    float moveWidth = movePoint.x;
   
    // UINavigationBar *preBar;(UINavigationBar动画待完成)
    
    
    
    //手势开始
    if (gesture.state == UIGestureRecognizerStateBegan) {
        
        toView.frame = CGRectMake(-toView.frame.size.width, toView.frame.origin.y, toView.frame.size.width, toView.frame.size.height);
    
    //手势改变
    }else if (gesture.state == UIGestureRecognizerStateChanged){
        if (movePoint.x > 0) { //从左往右滑动
            // moveWidth *scale
            toView.frame = CGRectMake(toView.frame.origin.x + moveWidth, toView.frame.origin.y, toView.frame.size.width, toView.frame.size.height);
            fromView.frame = CGRectMake(fromView.frame.origin.x + moveWidth, fromView.frame.origin.y, fromView.frame.size.width, fromView.frame.size.height);
        }
    //手势结束
    }else {
        
        if (fromView.frame.origin.x > [UIScreen mainScreen].bounds.size.width/2) {
            // pop
            [UIView animateWithDuration:0.4 animations:^{
                
                toView.frame = CGRectMake(0, toView.frame.origin.y, toView.frame.size.width, toView.frame.size.height);
                fromView.frame = CGRectMake(fromView.frame.size.width, fromView.frame.origin.y, fromView.frame.size.width, fromView.frame.size.height);
            } completion:^(BOOL finished) {
                NSMutableArray *viewAry = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                [viewAry removeLastObject];
                self.navigationController.viewControllers = viewAry;
            }];
        }else {
            // 还原
            [UIView animateWithDuration:0.4 animations:^{
                fromView.frame = CGRectMake(0, fromView.frame.origin.y, fromView.frame.size.width, fromView.frame.size.height);
                toView.frame = CGRectMake(-toView.frame.size.width, toView.frame.origin.y, toView.frame.size.width, toView.frame.size.height);
                
            } completion:^(BOOL finished) {
               
            }];
        }
    }
}

@end
