//
//  EOCNavAnimation.h
//  NavApply
//
//  Created by sy on 2017/10/16.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface EOCNavAnimation : NSObject<UIViewControllerAnimatedTransitioning, CAAnimationDelegate>

@end
