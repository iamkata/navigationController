//
//  EOCNavigationCtr.m
//  NavApply
//
//  Created by EOC on 2017/4/9.
//  Copyright © 2017年 EOC. All rights reserved.
//

#import "EOCNavigationCtr.h"
#import "EOCAnimationTransition.h"

@interface EOCNavigationCtr ()<UINavigationControllerDelegate, UIGestureRecognizerDelegate>{
    
}

@end

@implementation EOCNavigationCtr

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.delegate = self;
    
}

@end
